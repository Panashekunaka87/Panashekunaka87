## QR Generator For WhatsApp Bot In Base 64

#### Connect This Qr Generator With Your WhatsApp Bot In 4 Steps
##### ` 1: Copy This Qr Generator Link Or Copy Full [SCAN QR CODE ] Button 🔘`
##### ` 2: Past This Link In Your WhatsApp Bot README.MD File`
##### ` 3: Go In Your Bot [📁lib Folder/ then In Lib Folder Open [client.js] fil And Change Session Name In Replace Session Line And Put This Name 👉 SESSION-ID`
##### ` 4: Now Click On Commit Changes Now Your Session Connect With Your Bot`
<a href='https://qr-code-generator-eta-green.vercel.app/' target="_blank"><img alt='qr repo' src='https://img.shields.io/badge/Scan Qr code-black?style=for-the-badge&logo=openv&logoColor=white'/></a>


Support On Yt Technical Naveed

Credit To Me
Made With ❤️














___ 

---





----


# DATABASE URL FOR KOYEB 

postgres://koyeb-adm:kR0OM6mVATGX@ep-young-hall-a2rojz4x.eu-central-1.pg.koyeb.app/koyebdb
---





Copy And Use 

Thank You For Use 



---
Made With 💜


---

---
# PostgreSQL Uri / Url

postgres://naveed_user:jR4C57sJsFIBNO18OxxD6CtqzOvhTXYk@dpg-dn5D1nug2bec738cqi4g-a.frankfurt-postgres.render.com/naveed

postgres://udith_user:hR4C57sCgHIBNO18OxxD6CtqzOvhTXYk@dpg-ck5D1nug2bec738cqi4g-a.frankfurt-postgres.render.com/udith










---


---





# MONGODB URI &  BOTCAHX_API
 
 Copy Easy Now
 
 # `MONGODB URI`
  Railway Uri
 mongodb://mongo:Leua9VD8ienGyhpdruHQ@containers.railway.app:5534
 
Mongodb Uri


  ---
 # BOTCAHX_API   
1: Api = 6130a8cf

2: Api = 6140a9dg

3: Api = 7130a4dk

 ***BOTCAHX_API [`Click Here To Get Unlimited`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Api&Uri/README%20(1).md)***
 
 
 
 
 
Enjoy❤❤❤❤

----

# CARD 🃏 Details
⚜HEROKU WORKING CC⚜


CC: 4154644401602009

Expire: 08/25

CVV: 300

Name: Tbforce OFC

Country: Bahrain

Address: newtn OFC, house no. 7 block 40

City: Manama

State: Manama

Postal code: 323

⚜




---

# Plugins For All WhatsApp Bots
***Hermit-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(1).md)***

***Lyfee-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(2).md)***

***Secktor-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(3).md)***

***Prabath-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(4).md)***

***Suhail-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(5).md)***

***Xlicon-MD Plugin[`Click Here To Get`](https://github.com/naveeddogar/THINGS-For-Bots/blob/main/Plugins/README%20(6).md)***



More Bot Plugins Coming Soon...

---

# ALIVE MESSAGE For Hermit MD






.alive
*Hey* _&sender_

*I AM ALIVE!*

*RUNTIME*: &uptime
*SPEED*: &speed
*PLATFORM*: &platform

*QUOTE*: ```&quote```

_This Famous quote by *&author*_

#title\(っ◔◡◔)っ ♥ LOVE YOU ♥#
#body\Naveed-Bot#
#mediaUrl\#
#sourceUrl\https://wa.me/923096566451#
#thumb\https://i.imgur.com/tmylAFg.jpeg#
