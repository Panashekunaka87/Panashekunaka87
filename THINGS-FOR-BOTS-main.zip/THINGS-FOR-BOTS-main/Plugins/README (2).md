[](https://cardivo.vercel.app/api?name=TOTAL_PLUGINS%20&description=𝐏𝐋𝐔𝐆𝐈𝐍𝐒𝐂𝐎𝐔𝐍𝐓=𝟱𝟬&image=https://i.imgur.com/2NoFYTg.jpeg?q=tbn:ANd9GcR7aMC3bf4bg4l_nhYS2Un9FXbFYcB4T83Shjk8xSUZDh_D61LFpzbpeqLW&s=10?v=4&backgroundColor=%23e4f2f6&instagram=headless__angels.exo&github=mask-sir&) 
   <br>
<h1 align="center"> LYFE00011 PLUGIN LISTS </h1>
<div align="center">
  <!img align="center" alt="Coding" width="500" src="https://media2.giphy.com/media/oxjEQAAERDpRGp51D3/giphy.gif?cid=6c09b9526682283d53192f0e4f5ea1fc0b0caba1f016f472&rid=giphy.gif&ct=g"> <!br /> 
  <img border-radius: 30px src="https://i.imgur.com/dDcrb4k.jpeg" width="1000" height="300"/>

<br /> 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=LYFE-PLUGINLISTS&label=Visitors%20count&color=10d9c3&style=plastic" alt="lyfe-plugin-list" /> </p>
<details>
<summary>🤔HOW TO INSTALL PLUGIN??</summary>
<p>

<h2 align="center">  ➠ ʜᴏᴡ ᴛᴏ ɪɴsᴛᴀʟʟ ᴘʟᴜɢɪɴ
</h1>
<!CODED BY MASK SER>

✯ <ʜᴀɴᴅʟᴇʀ> ᴘʟᴜɢɪɴ <ᴘʟᴜɢɪɴ ʟɪɴᴋ>
<h3 align="center">  ➠ ʜᴏᴡ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴘʟᴜɢɪɴ</h1>
 

✯ <ʜᴀɴᴅʟᴇʀ>ʀᴇᴍᴏᴠᴇ <ᴘʟᴜɢɪɴ ɴᴀᴍᴇ>
</p>
</details>

<details>
<summary>📜 𝗜𝗡𝗗𝗘𝗫 📜 </summary>
<p>

## INDEX

* [EDITOR](#editor-plugins) 
* [FORWARD PLUGINS](#forward-plugins)
* [WHATSAPP RELATED](#whatsapp-related-plugins)
* [ANIME](#anime-plugins) 
* [DOWNLOAD PLUGINS](#download-and-converter-plugins)
* [CONVERTERS](#download-and-converter-plugins)
* [FUN & PRANK](#fun-and-prank-plugins)
* [STALKER](#stalker-and-search-plugins)
* [SEARCH](#stalker-and-search-plugins) 
* [RANDOM ](#random-images-and-videos)
* [HEROKU RELATED](#heroku-and-git-related-plugins)
* [OTHER PLUGINS](#other-usefull-plugins) 
* 📌 [NON-MD PLUGINS](#non-md-plugins)

[ʟʏғᴇ ɢɪᴛ-ᴍᴅ <a href="https://github.com/lyfe00011/whatsapp-bot-md">ᴠɪsɪᴛ <a/> ]<br />
</p>
</details>

### FOR PLUGIN EDITING TUTORIAL CLICK BELOW
 <a href="https://youtu.be/9PgSQzQn5Qc"><img src="https://img.shields.io/badge/-watch%20video-critical?style=for-the-badge&logo=youtube&logoColor=white">
   <br>
 

ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/Dimr0UROoRGFL58vhGbO7L)
  <div align="center"  
<h4 align="center">➥ PLUGINS</h1>


<details>

>__________________________________


<summary>🤔𝛮𝛯𝑊 𝛲𝐿𝑈𝐺𝛪𝛮𝑆</summary>
<p>

>__________________________________
ADDED
`Nowa`
`tomp3`
`gets`
`mfancy`
`GIT CLONE`
`SCAT`
`NPACK`
`OPEN`
`TO PDF`
`CKICK`
`COMMON`
`diff`
`pmbc`
`ipack`
`Fkick`
`checknum`
`PINCODE`
`NARUTO`
`PM BLOCKER`
`ephoto`
`cs`
`banchat`
`button`
`afd`
`areact`
`murl`
`age`
`attp`
`mttp`
`ttp`
`MTAG`
`vcard`
`msfor`
` AF`
`adurtion`
`nid`
`asize`
>___________________________________


</p>
</details>

>___________________________________


<h3 align="center">LYFE00011 MD BOT PLUGINS </h1><a href="https://github.com/mask-sir/LYFE-PLUGINLISTS"><img src="https://img.shields.io/badge/TOTAL%20MD%20PLUGINS%20%3D-121-green">

_________________________________________________
**[⬆ Back to Index](#index)**
### EDITOR-PLUGINS😍📌
<h4 align="center">  ᐉ  NPACK</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/aashin123">AASHIN</a>


```js
https://gist.github.com/aashin123/b91ee23c33e6babb01f6f043c7245b69
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT MAKER PLUGIN<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ IPACK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/AASHIN123">AASHIN</a>

```js
https://gist.github.com/aashin123/a77870f73cf2972d4a302fc00871825b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :TEXT TO IMAGE CONVERTER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ EPHOTO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>

```js
https://gist.github.com/lyfe00011/1d0d66838989a400c710c1ff19479c09
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :EPHOTO TEXT MAKER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTEXT TO PHOTO MAKER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/ajithaajitha952/ff75b87b4a2a716a5b7e3e9c556a0f4a
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO PHOTO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉLOGO MAKER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/alen-kenz">ALEN</a>


```js
https://gist.github.com/mask-sir/a5602867f5dbcfa13390955cda978ef5
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO LOGO  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉBANNER TEPLATES  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/f2ae110b21395d9bbbe138c601f1ea46/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : custom banner makers <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMEME GENERATOR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/72703ea0370cb35ddb203e3b5a119fd6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :ADD TEXT TO YOUR PHOTO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMTAKE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/bcc22c246e32a2d9424356d29b999856
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :change audio detils <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉGIF  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/lyfe00011/9a1ae6e4a7ec2425e330e5040cda2e43/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CONVERT VIDEO TO GIF <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉPHOTO EDITOR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/078fd972ac270b08ab23f39413e1fdc8
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : PHOTO EDITING BY GIVING URL <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TEXTMAKER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/120eee18e3c6b3c5b9a351120d9bf496
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE TEXT EFFECT PHOTS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉVOICE CHANGER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/8184816cacab0116bb39f32b3ad9aaf7
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUDIO EDITOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.fast / .robot
```
<br />
<br />

__________________________________
**[⬆ Back to Index](#index)**
### FORWARD PLUGINS🍒🔥
<h4 align="center">  ᐉ SIMPLE FORWARD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/8f3f1f952d9097e17a7f3493cdce4520
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SIMPLE FORWARD, MESSAGE VIA AD,RANDOM IMAGE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉCUSTOM FORWARD (AD VIA & LINK PRVIEW)  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MEHAFIL07">M E H 4 F I L</a>


```js
https://gist.github.com/Mehafil07/a688718fdcbed06807c98369d907c147
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :FULLY CUSTOMISABLE FORWARD WITH VIA AD REPLY,DOUBLE ORDER MSG,LINK PREVIEW<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.msfor ɪͥᴛͭsᷤ ͢ᴍͫᴇͤᡃ⃝Manu࿐⁩;⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻;01:06 ━━━━⬤─────── 04:05;111111111;111111111111111111;https://instagram.com;https://wa.me/917356159070;https://i.imgur.com/soghNME.jpeg;https://i.imgur.com/Y1MNRWF.jpeg;120363044083247727@g.us
```
<br />
<br />
<h4 align="center">  ᐉCUSTOM FORWARD (AD VIA)  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/fde458ecb93392002eb3dcad516a9a4f/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :FULLY CUSTOMISABLE FORWARD WITH VIA AD REPLY <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.af 20000;MASK SER;PLUGIN BENO MWONU;AANDHEDA PLUGIN VENO;https://i.imgur.com/NANXUiz.jpeg;https://i.imgur.com/NANXUiz.jpeg;https://wa.me/918921163912?text=gib+plugin+af+please;120363044083247727@g.us
```
<br />
<br />
<h4 align="center">  ᐉMFORWARD(NO-JID)  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/8fcca14fbc72292aeca639d38bd1037c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉATS(zmfor)  </h1>
 CONVERTED BY :<a href="http://www.github.com/alen-kenz">ALEN</a>


```js
https://gist.github.com/mask-sir/7f8fa479c8c362bc1b2f1c50792da251/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : MFORWARD WITH INSTGRAM LINK PREVIEW <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Ats MASK SER;BY MASK SER; ZMFOR GOING TO RELEASE ;111111111111;4005127;www.instagram.com/reels/osnsj;https://i.imgur.com/3CQLj9K.jpeg;https://i.imgur.com/b08knMk.jpeg;120363041103519586@g.us
```
<br />
<br />

<h4 align="center">  ᐉMFORWARD (with link preview) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/0ac8d675f903a8ad4e38d9640b477d64
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FORWARD REPLIED MESSAGE<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />


__________________________________
**[⬆ Back to Index](#index)**
### WHATSAPP RELATED PLUGINS💚
<h4 align="center">  ᐉ NOWA </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">HERMIT</a>


```js
https://gist.github.com/mask-sir/626dec3a85425c6e7d433e9719f3083a/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FILTER NUMBERS WHICH AREN'T REGISTERED ON WHATSAPP <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉRANDOM CAT STICKERS  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/NDROIDFF">NEERAJ</a>


```js
https://gist.github.com/Ndroidff/3b6ecc3a6d8ae1534a327d710077b629/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM CAT STICKERS<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ  GROUP OPEN </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e786a06e1c83e9fcef0b9d1454433f76
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GROUP OPEN FOR A GIVEN TIME<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ COMMON KICK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR"> MASK SER</a>

```js
https://gist.github.com/mask-sir/a91b8e45e9344300c33c7d5884127ebc
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : REMOVE COMMON MEMBER'S IN TWO GROUP <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ COMMON & DIFF </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>

```js
https://gist.github.com/mask-sir/4caf70d321a765f3cbb0e1c55543b4d5
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET COMMON OR DIFFERENT PARTICIPANTS IN TWO GROUPS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ PMBC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>

```js
https://gist.github.com/mask-sir/f54dfb624b621f5d6ecffc6d8e8979c8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : BROADCAST THE MESSAGE TO WHOLE THE GROUP MEMBERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ FAKE NUMBER REMOVING </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/ea9ea0855ab69fdad2ab0bbb0027dc6c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : REMOVES THE FAKE NUMBERS WITH GIVEN COUNTRY CODE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ LIST NUM </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/0919cfbe787b4e9c7653d32495fae266/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :LIST THE NUMBERS WITH GIVEN COUNTRY CODE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ PM BLOCKER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/e29a2211debd5d8a232abddbf5d4c50d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :BLOCKS EVERYONE WHO CAME PERSONAL CHATS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉ BUTTON </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>

```js
https://gist.github.com/lyfe00011/de7d9d2ff2e7c5c2c76ae3a418351afc
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :CUSTOM BUTTON <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ BANCHAT </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/d0d383c166046827cf28547b772dc22d/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DISABLE BOT MANAGER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ AUTO REACTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/be2115488a524631b7836d1ff2113d09
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUTOMATIC REACTION <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉAGE DETAILS  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/5cc5f514230ec60bde42c13402135350/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :DET DETAILS ABOUT YOUR AGE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉHIDE TAG  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/1db44f79f7dbe1d3bc1fec3e68fa63cd
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :HIDE TAG THE MSG <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ VCARD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/f7e2e3dc7e27f57b6b93b6ef03b675e7
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE CUSTOM VCARD <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉNID  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/0c56951e13ca882668326856c024d795/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET PHONE NUMBER OF THE REPLIED PERSON <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ INTRO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/viz-zer">VIZ ZER</a>


```js
https://gist.github.com/Viz-Zer/546ddc9b1755e11e0250c3488e77d642
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :self intro <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉOWNER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/dfc244f2e9b971ceb5f6138c89e7a168/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : OWNER VCARD <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ STATUS SENDER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/souravkl11">SOURAVKL11</a>


```js
https://gist.github.com/mask-sir/46661316cf95b4813960a4e2ce0507f1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUTOMATICALLY SEND STATUS TO THE VIEWERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGPNAME,GPP,GPDESC  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/14a99796c4885eaf3bae5a393369aa1c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CHANGE GROUP NAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉDM  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/1e255bc65f1fb7121a3b2ee7418e4431
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :pm message creator <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉSTATUS SAVER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/33df016b85fa5cb2a8f4e68be73ca9ce/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :send replied message to a specific jid <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉEMOJI TO PNG  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a9ee197e0c91b272e28c6aaaf3400aef
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CONVERT EMOJI TO PNG <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ STATUS SAVER(#) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/55e9f5780ec8168e2be00c45a9dffb91/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SAVES THE REPLIED STATUS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉEMIX  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe000111">LYFE</a>


```js
https://gist.github.com/lyfe00011/03fc0de72c912bb0784cd225e0b20490
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MIXES EMOJIS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ VV </h1>

 CONVERTED BY :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/lyfe00011/e9595f37d80ad9ee6d61a11ecb820b8c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD VIEW ONCE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ CAPTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/2ae359efa147d295dca8c1d53f88d947/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : COPY OR ADD CAPTION IN IMAGE OR VIDEO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ GJIDS(ALL GRP JIDS) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/fd1aff44918d4dad149ec69fbb153a88
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET ALL GROUP JIDS IN YOUR CHAT <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉWAME  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/Alien-alfa/d5e3bc953bcc6e1efaf8a9790a60724a/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : wame generator  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h3 align="center">  ᐉDELETE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/b73535d503bed41f5324344883cf0030
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DELETE ANY MESSAGE SENDED BY ANY TIME,BY USER OR BOT<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉGROUP JIDS </h1>
 
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANEBWOI</a>


```js
https://gist.github.com/mask-sir/85c95652f85958d307297cd3f5912070
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET JIDS OF THE GROUP MEMBERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉMEE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/turbogaming876">TOXIC DARCO</a>


```js
https://gist.github.com/turbogaming876/7ef131cee990be5884d73f08b8ae520b/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :SELF MENTION<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉ DOC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/a8f926710a28706679158887649ea145
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CONVERTE MESSAGES INTO DOCUMENT WITH NAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
_________________________________________________
**[⬆ Back to Index](#index)**
### ANIME PLUGINS👽🌈 
<h4 align="center">  ᐉ NARUTO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/bac1637b5a51dbc5cce4b19158477e11/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET RANDOM STATUS VIDEOS OF NARUTO UZUMAKI <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ RANDOM ANIME VIDEOS  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/48cdd7efde97e388bbc5fd8d04445e9d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET ANIME STATUS VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉANIME INFO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/d3d3c05dda769a90b6aba4eda6789a88/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GETS ANIME INFO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉLOLI  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/61fe8c9b5c03e56c6f29d1e30cce74d8
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM LOLI PICS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉCOUPLE PP  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/092dd40b3aa2c9c19063eabceb0a01b2/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :RANDOM COUPLE PHOTOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ WAIFU </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/842bdaa48f2b29eb52c6aabd171b1afe
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :random WAIFU Pics <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉANIME QUOTES  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/9997b0f20efcea733055da44778b0586/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GEY RANDOM ANIME QUOTS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ ANIMY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/824a55b1f0609ac8f2a4ada7e90d664c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :RANDOM ANIME IMAGE WITH QUOTE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

_________________________________________________
**[⬆ Back to Index](#index)**
### DOWNLOAD AND CONVERTER PLUGINS📩 
<h4 align="center">  ᐉ STICKER DOWNLOADER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/9af8301af82dcaae77dd96861935d4d1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :
SEARCH AND DOWNLOAD STICKERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMfancy  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/fa64029e1dd10730f62928bcd482183c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :FANCY TEXT GENERATOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TOMP3 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/33ea99220724ab44c16720e37249da49
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :
MP3 CONVERTER WITH AUDIO DATA <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TO PDF </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/280cc263b3a2d17e22eff270bc54ad69
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CONVERT PHOTO TO PDF<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ CS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>

```js
https://gist.github.com/SPARK-SHADOW/9fa2a5fb204f4dda538865680709d2f1/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE STICKER WITH 1:1 RATIO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉAUDIO TO URL  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/07175b35ffc538a0fd90d69105cd7698
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET DIRECT URL FOR MENTION AUDIO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMTTP, ATTP  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e009ccb325355f70c8f193721d9ac9f7/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :TEXT TO ANIMATED STICKER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ  TTP</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/e5610020ddab1dce177a890f23ad0ec8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :TEXT TO STICKER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉFAKE VOICE DURATION CREATOR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/2104d17dec85e3c6293aecca051cb50b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :ADD FAKE DURATION TO AUDIO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉFAKE MEDIA SIZE</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mehafil07">M E H 4 F I L</a>


```js
https://gist.github.com/mask-sir/b470d1c15780952bbb0e7810fecefc34/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : change audio size(fake size <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTOUP & TOLOW  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/4f3619bf4fd2f4811ba0700c80468481
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :TEXT TO CAPITAL AND SMALL LETTER CONVERTER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMALAYALAM SUBTITLE DOWNLOADER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/f0490d5b0c632d276e4b7764c630cbab
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD MALAYALAM SUBTITLE FROM MSONE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉREADMORE GENERATOR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/1c5b0872d47e8e31ce18bda7984e1ac7
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : READMORE GENERATOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGITHUB REPOSITORY DOWNLOADER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/dd7dc200faa5b18c9fcc37a84dcb7be3
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD ANY PUBLIC REPOSITORY FROM GITHUB <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ BASE64 ENCODE & DECODE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/627f58e88cd791fe43be21847e20f5d9/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : base64 encoder and decoder <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTEXT ENCODER & DECODER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a5a81a5ed4b0c0b2e03afa48aacab4c2
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO BINARY CONVERTER AND DECODER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TRANSLATOR </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/845b9de802e29f59c98a0a51d3045630
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ :GOOGLE TRANSLATOR lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉSPDF  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e0b14ba502c2c69767cbe95502cdabbc
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :convert given url to pdf <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉBARCODE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e7c312256f2acaf136be33750ae089bd
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CREATE BARCODE WITH THE GIVEN TEXT <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉCDATE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/deeac83034bbc5daa127653c9761279d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : MEASURE THE TIME GAP <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TG </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/785b3adb2796cae7b12912bf2500b2cb/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD STICKER FROM TELEGRAM <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ RVTXT</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a9840a826e93c8f1c0dd051808e3a440
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : REVERSE THE TEXT<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />


<h4 align="center">  ᐉ SHORT LINK(BITLY,TINY,CUTTLY,GG) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/0a4317cc375e57941aec4376c3d65c60
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SHORTING THE LINK <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />


<h4 align="center">  ᐉ PLAY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/56dbb82d05ebcd3ea614274e3996b29d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD SONG FROM YOUTUBE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
_________________________________________________
**[⬆ Back to Index](#index)**
### FUN AND PRANK PLUGINS👻
<h4 align="center">  ᐉSLOT  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/7db07fc3f1233cc57c666e2cb58962ea
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :SLOT GAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TRUTH OR DARE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/d9c1b8345c84bdacc46255dd4336feae
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TRUTH OR DARE GAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉFAKE ACTIONS  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/47c38b3cda045b974ed3b3bb01f367c1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :CREATE FAKE ACTIONS SUCH AS TYPING,RECORDING,ONLINE ETC... <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTINTU  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/56c5a8c3ee9f46f1ef735c79160b1fd5
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET RANDOM TINTUMON JOCKS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ DICE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/4f5a31ea7b48129787e142118abddeac/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :DICE ROLLING GAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉHECK  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/fasilvkn">FASIL</a>


```js
https://gist.github.com/fasilvkn/181ed05d6c06f8ae4ade81434024369c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : jst a prank plugin <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />


_________________________________________________
**[⬆ Back to Index](#index)**
### STALK AND SEARCH PLUGINS🔎🔎

<h4 align="center">  ᐉ GITHUB REPO SEARCH </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a0a3411e8931e5bfce87164b5d3ae5ed
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH FOR REPOSITORY IN GITHUB <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ ZIPCODE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>

```js
https://gist.github.com/mask-sir/e5480cf93c1dac5eaf38ad4dad4fe850/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET DETAILS ABOUT GIVEN PIN CODE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉGOOGLE SEARCH  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/84294e05f730823643195f76ab863b01
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH IN GOOGLE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGOOGLE REVERSE IMAGE SEARCH  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/c85fc9fbf2a2550eeb4f295636976712/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH WITH IMAGE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMOBILE INFO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/mask-sir/1b9cb65c2cfbc0c168eaeabc8ed376c1/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET ENTERED DEVICE DETAILS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ IG </h1>

 CONVERTED BY:<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/404b6ef1a4a4ab0ac14b58845213680a
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : INSTAGRAM PROFILE SEARCH <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉFIND  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/53c8dcc141fbff006ae6e216788ee290/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FINDS THE SONG IN THE AUDIO OR VIDEO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTRUE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/934954b89ca086f80c48bca2645ea6e6/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TRUECALLER SEARCH <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGTHUB  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/b2d7730b5c259fc5cf17438b3ca8e970/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GATHER INFORMATION FROM GITHUB FOR THE GIVEN USERNAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMODDROID SEARCH  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/97a794d3f08e312b89e69491b7468988
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH FOR MOD APPS IN MODDROID <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ MUSIC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/mask-sir/475c2f579eb0887724677b2f4fa22901
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GATHER MUSIC INFORMATION FROM ITUNES <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉWEATHER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/34fd7afd5b1b37aea6786e4e4020c715
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET WEATHER INFORMATION <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h align="center">  ᐉFAKE IDENTITY  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/ajithaajitha952/dc037ee82b8be783eb67bc586199e3f7/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GIVES  FAKE  DETAIL <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ LYRICS </h1>

 CONVERTED BY:<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/6cf06b4fc7ef6c3bbe2ba8eb8df138b6/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : get lyrics <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsappbot-md
<br />
<br />
<h4 align="center">  ᐉJEAN  </h1>

 CONVERTED BY:<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/04b7af2187c54b5971f7d9b402296585
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : LIKE ALEXA <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ YTL </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011"> LYFE</a>


```js
https://gist.github.com/mask-sir/1a7ff517accca3dc4d800f23506e93d8
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : YOUTUBE SEARCH WITH LIST <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />

_________________________________________________
**[⬆ Back to Index](#index)**
### RANDOM IMAGES AND VIDEOS😍📌🎰

<h4 align="center">  ᐉ🐔  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/8f0b5b442f40115b6d220b6eedd7ba5c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :RANDOM GIRLS PHOTOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ RANDOM WHATSAPP STATUS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/2ee22fc1846cf6e1630af4c64e4d0565
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM WHATSAPP STATUS SENDER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ XD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/cc8c22c484fc91669ad3f46442b8d32e
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM GIRLS DANCE VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMOUNTAIN  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/f1fc27c14aefeea15372f1200bd638ad
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM MOUNTAIN PICS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉPUBG WALLPAPER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/ajithaajitha952/2f225f0fe0d31a5e7bdeea24077b56ca
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM PUBG WALLPAPERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGAME WALLPAPERS  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ajithaajitha952">NIKHIL SER</a>


```js
https://gist.github.com/ajithaajitha952/b08408cbfe4121a96cc9681f2402173b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM GAME WALLPAPERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ GETFOOD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/0db1bdde00361b9b298b8b1857711375
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM FOOD PHOTOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ COFFEE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/4a598e21e1083b0eef59dd5a23bc72ee/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ: RANDOM COFFEE PIC <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />



_________________________________________________
**[⬆ Back to Index](#index)**
### HEROKU AND GIT RELATED PLUGINS📍
<h4 align="center">  ᐉSIMPLE UPDATER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/2a3265212efa2e814546f29601808f58/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : UPDATE CHECKS AND SIMPLE INTERFACE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMENU MD  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/9f978bfb314d0031036f942dd1ef3bde/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MENU OF LYFE MD BOT <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉSDYNO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/9a2bd716a32551dd5de14a5557f495fe/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SCHEDULE DYNO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.sdyno start 00 00 // .sdyno stop 00 00
```
<br />
<br />
<h4 align="center">  ᐉ SETSUDO,DELSUDO,GETSUDO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/c9b86f8327ca781160fbad2f4d0fbd66
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : sets/dels/gets sudo without entering heroku <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉGETQR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/d08a0878ece4a4f59752658822772234
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :GET LYFE-MD BOT QR IN WHATSPP <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉRESTART  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/f432cf8e9420ff39a6217ac266fe625d/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :quick restart <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

_________________________________________________
**[⬆ Back to Index](#index)**
### OTHER USEFULL PLUGINS🤔⭐

<h4 align="center">  ᐉLIVE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a232babba5a1f5e6f92a2d67f863cd91
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : LIVE TIME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />






<h4 align="center">  ᐉ CALC </h1>

 CONVERTED BY :<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/e10e123e74777416db6ef4c2dbc6a98c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : calculator <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTIME  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/470c297040daef2c7453ba4807f60e1b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GETS TIME INFO<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
















__________________________________
### NON-MD PLUGINS 
<a href="https://github.com/mask-sir/LYFE-PLUGINLISTS"><img src="https://img.shields.io/badge/TOTAL%20NON%20MD%20PLUGINS%20%3D-53-blue">

_________________________________________________
<h3 align="center"> EDITOR PLUGINS 👽🌈 <h1 />

<h4 align="center">  ᐉAUDIO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/01bf9387d9fc937b2ac54bd682551b73
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUDIO EDITOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.fast / .robot
```
<br />
<br />
<h4 align="center">  ᐉEMOJIMIX  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/3663f4c788dd0ab1cb980a3d83edcdce/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ 
:MIX THE EMOJIS lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.emix 😳😩
```
<br />
<br />

<h4 align="center">  ᐉ SPACK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/WAHID-BOT/860ea78cd0103f0d7c412804a50effad
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
: To create text photo logos <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.ipack
```
<br />
<br />

<h4 align="center"> ᐉFancy ttp</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/SPARK-SHADOW/37dc98cfbcbb45fb790deda1194e20d0
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : fancy ttp <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

<br />

<h4 align="center"> ᐉTrollmaker v1</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br />
ᴄʀᴇᴅɪᴛ ᴛᴏ :<a href="https://github.com/lyfe00011">lyfe00011</a> <br /> 

```js
https://gist.githubusercontent.com/insanebwoi/52bfee77544a45cd493f108dbef9977b/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :This plugin help you to make trolls include cat,dog trolls<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />
<h4 align="center"> ᐉT-MAKE</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br /> 

```js
https://gist.github.com/insanebwoi/5284ef05dee6dbb38d893c34bbf88fee
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help you to create custamaisable trolls by your choise by url<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />


# 🎮GAMES
### ᐉSTONE PAPER SCISSORS 
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/NJANRAZ">RAZ</a>

```js
https://gist.github.com/NJANRAZ/df82bdf4aca5e44def1bba7f778db188
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :stone paper scissors game <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
 ### ᐉ  slot

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/">DENIS</a>


```js
https://gist.githubusercontent.com/Whatsden/ff487de5452ef633fee2cf2e8595d7cd/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :play a game<b/>
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center" > FORWARD PLUGINS ➡️ <h1 />
<h4 align="center" > FIRST WATCH THIS VIDEO AND USE MFORWRD PLUGINS </h1> 
 <a href="https://youtu.be/9PgSQzQn5Qc"><img src="https://img.shields.io/badge/-watch%20video-critical?style=for-the-badge&logo=youtube&logoColor=white">
   <br>

<h4 align="center">  ᐉsend plugin </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/farhan-dqz">farhan-dqz</a>


```js
https://gist.githubusercontent.com/farhan-dqz/67ba8fed33aa4f36083cf94788aed31d/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Basic version of forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center">  ᐉ m-forward with fake preview status (.mforward) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.github.com/lyfe00011/467a2e45f4e36b8bb4782ee8da573ca0
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : improved version of forward.You can add any link in the body section (group link, YouTube,wame link etc...)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ Need edit this plugin for make customasable 
<br />
<br />


<h4 align="center">  ᐉ m-forward custamaisable verify tick status (.cmfor)  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/a256b2751ad6298b5374eb40f9f62758
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ No Need edit this plugin on github   <br/>
• you can even customize all things in this plugin eg url,caption,duration etc <br/>
**Use by Given format** <br/>
```js
Example .cmfor caption;99;https://i.imgur.com/BiLC1Ik.jpeg;jid1 jid2 jid3 jid4 ...
```
<br />
<br />




<h4 align="center">  ᐉ m-forward media preview with fully custamaisable (.zmfor) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/3d3f705f5b9e6f38e0de47745530a312
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward with media preview <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ No Need edit this plugin on github  <br/>
• you can even customize all things in this plugin eg url,caption,head,body,duration,price,url,url2 etc <br/>
**Use by Given format** <br/>
Example 

```js
.zmfor ᴇxᴀᴍᴩʟᴇ ꜰᴏʀ ᴢᴍꜰᴏʀ;ᴍꜰᴏʀᴡᴀʀᴅ ᴍᴇᴅɪᴀ ᴩʀᴇᴠɪᴇᴡ ᴡɪᴛʜ ᴄᴜꜱᴛᴀᴍᴀɪꜱᴀʙʟᴇ ᴀᴅᴇᴅᴅ ᴛᴏ ᴩʟᴜɢɪɴ ʟɪꜱᴛ✔️;ᴩʟᴇᴀꜱᴇ ɢᴏ ᴀɴᴅ ᴄʜᴇᴄᴋ🔛;100;2022000;https://www.instagram.com/tv/CX8_LOXByX3/?utm_medium=copy_link;https://i.imgur.com/uLIOJBs.jpeg;https://i.imgur.com/F7KxLWv.jpeg;0@s.whatsapp.net
```

NB : PRICE TAG MUST ABOVE 100000 = ₹100.00 <br/>
     DURATION 100 = 1:40 sec 
<br />
<br />







<h4 align="center">  ᐉm-forward random custamaisable duration & title verify tick status </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/d7173ff5f8137e8bfc7d97ff61c41d49
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ Your choice on editing or not this plugin youcan custamaise it by changing url in the programme <br/>
• you can even edit all things in this plugin exclude url  <br/>
**Use by Given format** <br/>
Example
```js
.crfor example;99;jid1 jid2 jid3 jid4 ...
```
<br />
<br />

<h3 align="center" >PRANK & FAKE PLUGINS👻 <h1 />
<h4 align="center">  ᐉJZHECK  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/jasimjz">JZ MODS</a>


```js
https://gist.github.com/Jasimjz/c729a932c9d064f1a9ff9e45fe8c2501
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : PRANK PLUGIN FOR FUN <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center"> ᐉ Scam typing&recording </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/SPARK-SHADOW/aa3991992fae718edb75b380336aff24
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin make scam typing, recording voice to prank others <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />
.stop scam   to stop this in 20 sec <br />

<h4 align="center">  ᐉHACK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.githubusercontent.com/SPARK-SHADOW/14d9be053f21192f31e79baaf96c2852/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ:Fake hack plugin for just prank <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉCHERRYHECK  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANEBOY</a>


```js
https://gist.github.com/mask-sir/a2f9ad2b1735f154f5e38796c1535ac6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴɪɴ:Fake hack plugin for just prank <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ TRUE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://github.com/shefinkl14">SHEFIN</a>


```js
https://gist.github.com/mask-sir/84df6b7066370735304e63f9db66379f
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ
 : Fake Truecaller plugin (og not released)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center" > WHATSAPP REALTED PLUGINS🪀 <h1 />
<h4 align="center">  ᐉTRUECALLER😍  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/Souravkl11">SOURAV</a>


```js
https://gist.github.com/souravkl11/156a01ae93836f3c13c48b92c6d074af
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH IN TRUECALLER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h5 align="center">  ᐉCLR </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/LoveYou0011">ELDRIN</a>


```js
https://gist.githubusercontent.com/LoveYou0011/ffe47541370a862894403847f0fcb90b/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CLEAR CHAT  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center">  ᐉ CAPTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/581702e4bb93186c7730cbc18dfe1d98/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : ADD OR GET THE CAPTIONS OF IMAGES OR VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center"> ᐉAnti view once </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.githubusercontent.com/lyfe00011/582ff0b2f2e61cc0cf4ea48084d52cb0/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help you to convert view once media to normal media by camand <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />

<h4 align="center">  ᐉ GPJIDS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANE BOY</a>


```js
https://gist.github.com/mask-sir/d273d9b05f938a6cf1181c4f213a67c8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
:  To get full member jids.you can ut for pmbc, audiobc, broadcast to all<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ MEE</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/5e088a997da3d81dbd1f2cca57ac4bca/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ:self MENTION<br
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />


<h4 align="center">  ᐉ PM  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/mask-sir/4f062aa3e3adca278e1805f09af2935a/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEND THE OWNER VCARD<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />


<h4 align="center">  ᐉ YOU </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/iam-arya">ARYA</a>


```js
https://gist.github.com/mask-sir/c61b8efb686d7cbc077d7ebdd84a4ec6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : mention the replied person lyfe00011
<br />
<br />

<h align="center">  ᐉ IM </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.github.com/mask-sir/af610e4911906459866d026b773bfb02
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : ADD NOTEPAD OR DETAILS (EDIT AND USE)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ Dlt </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANE BOY</a>


```js
https://gist.github.com/insanebwoi/baedffadfc3c492399e120f
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DELETE THE MESSAGE SEND BY THE BOT (NO TIME LIMIT,NOT DELETE MSG SENDED BY THE USER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h align="center">  ᐉ STATUS SAVER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/mask-sir/80f32efa9208e4194fd281f9ef9b8b54/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :save the status  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.#
```
<br />
<br />



<h4 align="center">  ᐉLIST ONLINE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/1bf6af13bed8e780033836d5ba665547/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉRENAME, SETDESC,GPP </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.github.com/mask-sir/cafa4bf05c7fa66a93a159872a511dd1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
:To change group name/desc/dp<br /> 
``` js
https://gist.github.com/fasilvkn/69105233899e9d033fcc7a27bee9c1e1/raw
```
For changing group profile
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center"> OTHER USEFULL PLUGINS😻 <h1 />
<h4 align="center">  ᐉANIMY  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/NJANRAZ">RAZ</a>


```js
https://gist.github.com/mask-sir/d6ef3531d9162a08657103f341609f35/raw

```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME PHOTO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
### ᐉ BUTTON 

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/1df704a43dc82513679020d701b63767/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE BUTTON MESSAGE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Button HELLLO,©MASK,TEST,DONE
```
<br />
<br />
<h3 align="center">  ᐉ CALC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/68fc7fbd4b007dfcb8c3f3e293ea2934/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TO CALCULATE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.calc 1+1 / 1*1 /1-1 / (1/1)
```
<br />
<br />
<h4 align="center"> ᐉ Cropped Sticker</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a>



```js
https://gist.githubusercontent.com/SPARK-SHADOW/7a03decfda97e6da7606880d9db85456/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :This plugin help you to make sticker by croping in ratio 1:1<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />

<h4 align="center"> ᐉFancy menu v3 (updated)  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.github.com/SPARK-SHADOW/2633547513e2fa88e9af5296961598b2
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Modified version of menu with time and date <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />

### ᐉ Setsudo,delsudo,getsudo 

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/9aa68a52481c439fd6aee2958a7833a3/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪn :set/delete/get sudo without typing var cmnd: <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.setsudo <nbr>/ replay or mention to a person (.setsudo @.....)
```
<br />
<br />

###  ᐉ IG  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="www.github.com/lyfe00011">LYFE</a>

```js
https://gist.github.com/lyfe00011/83a379a3aa375249962e49a734df8bbf/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH THE USERNAME ON INSTAGRAM AND GETS THE PROFILE DETAILS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Ig <username>
```
<br />
<br />
<h5 align="center"> ᐉ Text  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/0cdaab914811d3e88f2357e7cd1deac2/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE FONTS WITH DOTED LINES <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />



### ᐉ WAME[with green tick and name]</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e6f02413f74453ad0ae31c5b7d965d7b/raw
```
### without green tick (fast sending)
```js
https://gist.github.com/mask-sir/a0d16d6ea93d6ce1c6b5e0c7ab52da7e
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Gets the invite link of the replied person <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center"> ᐉSub title</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.github.com/lyfe00011/ef753048e046495b7fdb04747299b834
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin gev you Subtitle <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

<h4 align="center"> ᐉLive time</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br /> 
ᴄʀᴇᴅɪᴛ ᴛᴏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/insanebwoi/fb0f9f34e0b36c3b3adc0a3bda2bb8c0/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : You can know which time it is by this plugin <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />


<h4 align="center"> ᐉ Custamaisable list </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://gist.github.com/Whatsden">Whatsden</a> <br /> 

```js
https://gist.github.com/Whatsden/02858adcf132ceac66b847d232ba08f8
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help to create list esly by geven example <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />
Example geven below
```js
.buttlist Message,click here,heading,list1,list2,list3
``` 
<h4 align="center"> ᐉNUM </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/6b824f6957d9ac97d7b348ff376e2ace/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FILTER THE CONTRY NUMBERS<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ KIK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/sweetscherry/701f7181f8b4e93aa3955dfe47bce9db/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : removes the person with all matching numbers lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.kik 91
```
<br />
<br />
<h4 align="center">  ᐉ PLAY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/ffc1d10b63154bc3870717d2ab7ffcf0/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Download the song from YouTube<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.play beliver
```
<br />
<br />
<h4 align="center">  ᐉ GQR </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/9f07e4048e95824c886c14c2550f90bc/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ : make the qr code of Given text <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h align="center">  ᐉ DOC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/ca1d9edf4ae2af7ad08f079f10da4d22/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : convert the reolied message to document<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ TLINK</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/e6ead0c956dc853ba3c7db1c87b006d9/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Covert the replied message to link <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ :lyfe00011
<br />
<br />
<h4 align="center"> jean ᐉ  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/4d5c4b2a71930b66e829182f632ab9c8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : search the querry <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.jean question
```
<br />
<br />

__________________________________
__________________________________

## ▣ Need to add your plugin here?
## [![Typing SVG align="center"](https://readme-typing-svg.herokuapp.com?font=Staatliches&color=0A0089&size=20&width=350&lines=We+know+there+are+a+lot+of+plugin;didnt+include+here+...;If+you+created+a+use+full+plugin;and+didnt+here+???;Contact+us+to+add+here+🙂;After+checking+the+use+and+scan;We+given+a+whatsapp+link+above;join+there+and+contact+us;If+there+is+a+problem+in+any+plugin;there+please+contact+us+......)](https://git.io/typing-svg) <br/>
<br/>

## ✆ Contact us 
<details>
<summary>🎈INFO</summary>
<p>

[ᴄᴏᴘɪᴇᴅ ғʀᴏᴍ <a href="http://github.com/insanebwoi/lyfe-plugins-list">ɪɴsᴀɴʙᴡᴏɪ <a/> ]<br />
ᴄᴀɴ ʏᴏᴜ ɢɪᴠᴇ ᴍᴇ ᴀ sᴛᴀʀ ✫  ☻ <br /> <br />

#### ᴄᴏɴᴅʀɪʙᴜᴛᴇ ᴛᴏ ❁ <br />
『 ʟʏғᴇ sᴇʀ 』 <br />
『 ᴍᴀsᴋ sᴇʀ』 <br />
『 ɪɴsᴀɴᴇʙᴡᴏɪ 』 <br />

</p>
</details>
<br />

### ᴛʜɪs ʙʟᴏɢɢᴇʀ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ✎<br />
◨ ᴍᴀsᴋ sᴇʀ◧ <br />

 ©Lyfe 00011 USER BOT
