<h1 align="center"> HERMIT-MD PLUGINS </h1>
<div align="center">
  <img border-radius: 30px src="https://i.imgur.com/6oYvCER.jpeg" width="1000" height="300"/>

<br /> 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=hermit-md-plugins&label=Visitors%20count&color=10d9c3&style=plastic" alt="lyfe-plugin-list" /> </p>
<details>
<summary>🤔HOW TO INSTALL PLUGIN??</summary>
<p>

<h2 align="center">  ➠ ʜᴏᴡ ᴛᴏ ɪɴsᴛᴀʟʟ ᴘʟᴜɢɪɴ
</h1>
<!CODED BY MASK SER>

✯ <ʜᴀɴᴅʟᴇʀ> ᴘʟᴜɢɪɴ <ᴘʟᴜɢɪɴ ʟɪɴᴋ>
<h3 align="center">  ➠ ʜᴏᴡ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴘʟᴜɢɪɴ</h1>
 

✯ <ʜᴀɴᴅʟᴇʀ>ʀᴇᴍᴏᴠᴇ <ᴘʟᴜɢɪɴ ɴᴀᴍᴇ>
</p>
</details>

<details>
<summary>📜 𝗜𝗡𝗗𝗘𝗫 📜 </summary>
<p>

## INDEX

* [PLUGINS](#editor-plugins) 
</p>

 GIT LINK:- [CLICK HERE](https://github.com/A-d-i-t-h-y-a-n/hermit-md)

</details>

   <br>
 
ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/LOMGBEO2i9vKew562o1LFk)
  <div align="center"  



<details>

>__________________________________


<summary>🤔𝛮𝛯𝑊 𝛲𝐿𝑈𝐺𝛪𝛮𝑆</summary>
<p>


>_____________________

ADDED
`pmblocker`
`playstore`
`slot`
`sample plugins`
`piceditor`
`autosticker`
`funpack`
`fkick`
`buyfood`
`buycoffee`
`enc`
`uglify`
`mser`
`shortlink`
`intro`
`bgm`
`calc`
`cdate`
`rvtxt`
`encode & decode`
`num`
`ujid`
`log`
`getjids`
`notepad`
`gfxpack`
`nowa`
`scat`
`birth`
`aquote`
`gets`
`auto forward`
`vv`
`sexy`
`textpro`
`couple`
`loli`
`waifu`
`auto group link delete`
`mdfor`
`joke`
`tintu`
`naruto`
`sanime`
`status`
`setsudo`
`astatus`
`#`
`fd`
`owner`
`play`
`mee`
`mforward`
`auto_reactionn`
`mention`

>___________________________________


</p>
</details>

>___________________________________


<h3 align="center">HERMIT-MD PLUGINS</h1><a href="https://github.com/mask-sir/hermit-md-plugins"><img src="https://img.shields.io/badge/TOTAL%20MD%20PLUGINS%20%3D-54-blue">


### 𝙂𝞢𝙏 𝞓𝙇𝙇 𝞠𝙇𝙐𝙂𝞘𝞜𝙎 𝙅𝙐𝙎𝙏 𝞑𝙔 𝞘𝞜𝙎𝙏𝞓𝙇𝙇𝞘𝞜𝙂 𝙏𝞖𝞘𝙎:-
```
https://gist.github.com/mask-sir/437edbf49c2ffc23c9323c78e8604f88/raw
```
<h4 align="center">  ᐉ 𝗘𝗫𝗔𝗠𝗣𝗟𝗘 𝗣𝗟𝗨𝗚𝗜𝗡 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/c7499cf3aaf8a1790b64e73db8c14740
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙴𝚇𝙰𝙼𝙿𝙻𝙴 𝙿𝙻𝚄𝙶𝙸𝙽 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />

_________________________________________________
**[⬆ Back to Index](#index)**

### PLUGINS😍📌


<h4 align="center">  ᐉ 𝗣𝗠𝗕𝗟𝗢𝗖𝗞𝗘𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/4919ee9ecf4f76d49635e9b23a63dc78
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝚊𝚞𝚝𝚘𝚖𝚊𝚝𝚒𝚌 𝚙𝚎𝚛𝚜𝚘𝚗𝚊𝚕 𝚌𝚑𝚊𝚝 𝚋𝚕𝚘𝚌𝚔𝚒𝚗𝚐 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗣𝗟𝗔𝗬𝗦𝗧𝗢𝗥𝗘 𝗦𝗘𝗔𝗥𝗖𝗛 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/nizamparkerz">𝐍𝐈𝐙𝐀𝐌</a>


```js
https://gist.github.com/nizamparkerz/f5d3c2c53f919ead43141f2a1572d12e
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝙿𝙻𝙰𝚈𝚂𝚃𝙾𝚁𝙴 𝚂𝙴𝙰𝚁𝙲𝙷 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗦𝗟𝗢𝗧 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ A-D-I-T-H-Y-A-N"> 𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/02b0e79cfb34afb1ef5bf9982991c67a
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚂𝙻𝙾𝚃 𝙶𝙰𝙼𝙴 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗣𝗜𝗖𝗘𝗗𝗜𝗧𝗢𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/nizamparkerz">𝐍𝐈𝐙𝐀𝐌</a>


```js
https://gist.github.com/nizamparkerz/9050b4ad49fb184f498767c65e1ff594/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙿𝙷𝙾𝚃𝙾 𝙴𝙳𝙸𝚃𝙾𝚁𝚂 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗔𝗨𝗧𝗢 𝗦𝗧𝗜𝗖𝗞𝗘𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ A-D-I-T-H-Y-A-N"> 𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/mask-sir/ac744367d3e5c1ecb19a93eec1c9f375
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚊𝚞𝚝𝚘 𝚖𝚊𝚝𝚒𝚌 𝚜𝚝𝚒𝚌𝚔𝚎𝚛 𝚛𝚎𝚜𝚙𝚘𝚗𝚜𝚎 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗙𝗨𝗡 𝗣𝗔𝗖𝗞 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/9b167c0a773af68c9fb42506fa829f09
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙵𝚄𝙽 𝙿𝙰𝙲𝙺𝚂 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗙𝗞𝗜𝗖𝗞 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/ebe76d695115e437c5fb621b5b126cfb
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙵𝙰𝙺𝙴 𝙽𝚄𝙼𝙱𝙴𝚁 𝚁𝙴𝙼𝙾𝚅𝙴𝚁 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗕𝗨𝗬𝗙𝗢𝗢𝗗 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/7b6ff656838a0e0cdb42a1bdd327bb5d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙶𝙴𝚃 𝚁𝙰𝙽𝙳𝙾𝙼 𝙵𝙾𝙾𝙳 𝙿𝙸𝙲𝚂 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗕𝗨𝗬𝗖𝗢𝗙𝗙𝗘𝗘 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/e08aa660f7852502be7401f053e2ece0
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙶𝙴𝚃 𝚁𝙰𝙽𝙳𝙾𝙼 𝙲𝙾𝙵𝙵𝙴𝙴 𝙿𝙸𝙲𝚂 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗝𝗦-𝗢𝗕𝗙𝗨𝗖𝗔𝗧𝗢𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ A-d-i-t-h-y-a-n">𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/mask-sir/b69121eb6f54649c2ecd5f4d000b208f
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝚓𝚊𝚟𝚊𝚜𝚌𝚛𝚒𝚙𝚝 𝚘𝚋𝚞𝚏𝚞𝚜𝚌𝚊𝚝𝚘𝚛 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗖𝗢𝗗𝗘 𝗠𝗜𝗡𝗜𝗙𝗬 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-ser">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/997afa311fd34aa28361c9d596723978
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙲𝙾𝙳𝙴 𝙼𝙸𝙽𝙸𝙵𝚈, 𝙱𝙴𝙰𝚄𝚃𝙸𝙵𝚈 𝙰𝙽𝙳 𝚄𝙶𝙻𝙸𝙵𝚈 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗠𝗦𝗘𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mrlinux0007">𝐀𝐃𝐄𝐄𝐋</a>


```js
https://gist.github.com/mrlinux007/dd18b5aca4e6474673b85b2054df77cf
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚛𝚊𝚗𝚍𝚘𝚖 𝙵𝙵𝙲 𝚜𝚝𝚒𝚌𝚔𝚎𝚛𝚜 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗟𝗜𝗡𝗞 𝗦𝗛𝗢𝗥𝗧𝗡𝗘𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-ser">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/e39cbfd90666bac6947f33caa91e59e6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚜𝚑𝚘𝚛𝚝 𝚝𝚑𝚎 𝚐𝚒𝚟𝚎𝚗 𝚕𝚒𝚗𝚔 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗜𝗡𝗧𝗥𝗢 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/Viz-Zer">𝐕𝐈𝐙 𝐙𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/21ae31b0633e9316ae7187c846e94fbf
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚂𝙴𝙻𝙵 𝙸𝙽𝚃𝚁𝙾 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗕𝗚𝗠 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>
           &<a href="http://www.github.com/A-d-i-t-h-y-a-n">ADITHYAN</a>



```js
https://gist.github.com/A-d-i-t-h-y-a-n/f8b17ad4e66f8c2d8f1ed7b3d16f8cea/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙱𝙶𝙼 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗖𝗔𝗟𝗖𝗨𝗟𝗔𝗧𝗢𝗥 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ A-D-I-T-H-Y-A-N"> 𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/mask-sir/58d0689fdb7f24cfae2ee0e275b225d9
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚂𝙸𝙼𝙿𝙻𝙴 𝙲𝙰𝙻𝙲𝚄𝙻𝙰𝚃𝙾𝚁 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗖𝗢𝗨𝗡𝗧 𝗗𝗔𝗧𝗘 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/8a49d4e1c2d0fa8bee2d6d23cad9ed0a
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙲𝙾𝚄𝙽𝚃 𝚃𝙷e 𝚁𝙴𝙼𝙰𝙸𝙽𝙸𝙽𝙶 𝙳𝙰𝚈𝚂 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗥𝗘𝗩𝗘𝗥𝗦𝗘 𝗧𝗘𝗫𝗧 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/4627666d32294870b525a288eaf49681
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚁𝙴𝚅𝙴𝚁𝚂𝙴 𝚃𝙷𝙴 𝚃𝙴𝚇𝚃 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗘𝗡𝗖𝗢𝗗𝗘𝗥𝗦 𝗔𝗡𝗗 𝗗𝗘𝗖𝗢𝗗𝗘𝗥𝗦 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/379dd75c62c15f845e5bbec6ffb106eb
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝚋𝚊𝚜𝚎𝟼𝟺,𝚑𝚎𝚡 𝚎𝚗𝚌𝚘𝚍𝚎𝚛 𝚊𝚗𝚍 𝚍𝚎𝚌𝚘𝚍𝚎𝚛 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗡𝗨𝗠 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/f72ff49075c8834738946729ef4155cd
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝚏𝚒𝚕𝚝𝚎𝚛 𝚌𝚘𝚞𝚗𝚝𝚛𝚢 𝚌𝚘𝚍𝚎 𝚒𝚗 𝚐𝚛𝚘𝚞𝚙 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗨𝗝𝗜𝗗 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/49e208676335df91fd1108f55e4e1aba/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚐𝚎𝚝 𝚊𝚕𝚕 𝚖𝚎𝚖𝚋𝚎𝚛𝚜 𝚓𝚒𝚍𝚜 𝚒𝚗 𝚐𝚛𝚘𝚞𝚙 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗟𝗢𝗚 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/aba65f48f7f61342c7c2f004ea5bb59f/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙶𝙴𝚃 𝙻𝙾𝙶 𝙾𝙵 𝚃𝙷𝙴 𝚁𝙴𝙿𝙻𝙸𝙴𝙳 𝙼𝙴𝚂𝚂𝙰𝙶𝙴 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗴𝗲𝘁𝗷𝗶𝗱𝘀 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/8e4f1aae2094148daba24a7b907bb08b/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚐𝚎𝚝 𝚊𝚕𝚕 𝚐𝚛𝚘𝚞𝚙𝚜 𝚓𝚒𝚍𝚜 𝚊𝚗𝚍 𝚗𝚊𝚖𝚎 𝚒𝚗 𝚊𝚌𝚌𝚘𝚞𝚗𝚝 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗡𝗢𝗧𝗘𝗣𝗔𝗗 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/95fd3c5fc025e3aa35ff468d3ce0f937
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝚂𝙰𝚅𝙴 𝙼𝙴𝚂𝚂𝙰𝙶𝙴 𝙻𝙸𝙺𝙴 𝙰 𝙽𝙾𝚃𝙴𝙿𝙰𝙳 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗚𝗙𝗫𝗣𝗔𝗖𝗞 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">𝐌𝐀𝐒𝐊 𝐒𝐄𝐑</a>


```js
https://gist.github.com/mask-sir/bdd39595edfb0693eb6fc6f046cb43ea
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :𝙶𝙵𝚇 𝙻𝙾𝙶𝙾 𝙼𝙰𝙺𝙴𝚁 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ 𝗡𝗢𝗪𝗔 </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N"> 𝐀𝐃𝐈𝐓𝐇𝐘𝐀𝐍</a>


```js
https://gist.github.com/mask-sir/057c2ea4eec15f737dac5f3a03a5e432
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : 𝙵𝙸𝙻𝚃𝙴𝚁 𝙽𝚄𝙼𝙱𝙴𝚁𝚂 𝚆𝙷𝙸𝙲𝙷 𝙰𝚁𝙴𝙽'𝚃 𝚁𝙴𝙶𝙸𝚂𝚃𝙴𝚁𝙴𝙳 𝙾𝙽 𝚆𝙷𝙰𝚃𝚂𝙰𝙿𝙿 <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ SCAT </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">NEERAJ</a>


```js
https://gist.github.com/mask-sir/9875afaf31368bdd8236330be1940693
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET RANDOM CAT STICKERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ BIRTH  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/22a4dfc1a651e205143c7d651794cb7b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET DETAILS ABOUT YOUR BIRTH <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ AQUOTE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/bcceab11dc4a3c7659dd9610b649ec7c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME QUOTE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ STICKER DOWNLOADER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/3fb3c4ac7fe4fd9014284c5419fa65b5
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH AND DOWNLOAD STICKERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ AUTO FORWARD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/9f302750ad3cda876f9f0e8454b090d0
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUTOMATICALLY FORWARD VIDEOS TO ONE GROUP TO ANOTHER GROUPS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ ANTI VIEW ONCE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/46161ab33b41f6066166421c5c505f98
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :ANTI VIEW ONCE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ SEXY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/5d11585aaf89193f303f1664cd2b1bdd/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM TIK TOK DANCE VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ TEXT PRO(TEXT MAKERS) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/33f2865fd1c05533b7143752bf929959
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO PIC OR STICKER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ COUPLE PP </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/616e86ef8da64b9a4c95dbb84427f0ed
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM COUPLE PHOTOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ LOLI </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/f55b61c0b92fde6b949c1656d4b9e5b1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME PICS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ WAIFU </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/8916d7ff995a308216c0a505b26c78c4
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME PICS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />

<h4 align="center">  ᐉ AUTO GROUP LINK DELETE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/cbc0fe6e83d462d49db5d70ebb871799/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUTOMATICALLY DELETE GROUP LINKS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉMdFOR  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/6bc61840ea6232224f2ce8d8cf29b8d4/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FORWARD PLUGIN <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.mdfor 𝛥𝑅⁷⁷⁷;                 ⇆ㅤ ||◁ㅤ❚❚ㅤ▷||ㅤ ↻;07:05 ━━━━━━━━━━⬤──────────── 77:55;555555555555555;-77777777777777777;https://Instagram.com/hehe;https://wa.me/972528277755;https://i.imgur.com/XeKniGM.jpeg;https://i.imgur.com/9tRtHHn.jpeg;687823333@s.whatsapp.net
```
<br />
<br />
<h4 align="center">  ᐉ JOKE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/15feb2217e6bedb9af9ccf289c3d38a1/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FUNNY JOKES <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />

<h4 align="center">  ᐉTintu  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/c0f4ec693b140feb47987257ae568d07
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TINTU MON JOKES <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ SETSUDO,DELSUDO,GETSUDO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e40140e7df3e8537675b84ab4d3be6ea/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SET, DELETE, SHOWS SUDO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ SANIME  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/7154c7a708f0db857e3685d227e8cb86
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ NARUTO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/debfea6654c6c3e85df67d7768eb8e39
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM NARUTO STATUS VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ STATUS  VIDEOS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```jshttps://gist.github.com/mask-sir/1782582cca188f8cebaf1202076141f8

```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM MALAYALAM STATUS VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />

<h4 align="center">  ᐉ AUTOMATIC STATUS SENDER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/b46c0e947aa7952b6edf7423df08810e
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEND THE STATUS IF ANYONE ASK TO SEND <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />
<h4 align="center">  ᐉ STATUS SAVER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/mask-sir/3a865722fee78633abc610536f022959
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : STATUS SAVER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : hermit-md
<br />
<br />

<h4 align="center">  ᐉ FD </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/mask-sir/e7dfd0b31fd2544832e7519471219e7c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FORWARD MESSAGE WITH AUDIO WAVE AND THUMBNAIL<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
<h4 align="center">  ᐉ OWNER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/mask-sir/c83ba1bcf19279ffaa1bbce3db2803eb/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :OWNER VCARD <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
<h4 align="center">  ᐉ PLAY  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/f6f29b6d4356046467c4acf027ae9c2b/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : PLAY SONG <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
<h4 align="center">  ᐉ MEE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/MASK-SIR">MASK SER</a>


```js
https://gist.github.com/mask-sir/35ec40c8ee0bb2a28caf0c2ede986be8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SELF MENTION <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />

<h4 align="center">  ᐉ MFORWARD  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/98381c045612b08fb26b3723556383ff
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FORWARD PLUGIN WITH LINK PREVIEW<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
<h4 align="center">  ᐉ AUTO REACTION  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/86f31f243b416cc957a6aefd7799ce2c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUTOMATIC RANDOM REACTION SENDER<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
<h4 align="center">  ᐉ MENTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/A-D-I-T-H-Y-A-N">ADITHYAN</a>


```js
https://gist.github.com/A-d-i-t-h-y-a-n/05ba2c693a4793fe6c1db452a6191207
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEMPORARY MENTION AUDIO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : Hermit-md
<br />
<br />
__________________________________
__________________________________

## ▣ Need to add your plugin here?
### ▣ JOIN THE WHATSAPP GROUP
<br/>

## ✆ Contact us 
<details>
<summary>🎈INFO</summary>
<p>

ᴄᴀɴ ʏᴏᴜ ɢɪᴠᴇ ᴍᴇ ᴀ sᴛᴀʀ ✫  ☻ <br /> <br />

#### ᴄᴏɴᴅʀɪʙᴜᴛᴇ ᴛᴏ ❁ <br />
『 HERMIT 』 <br />

</p>
</details>
<br />

### ᴛʜɪs ʙʟᴏɢɢᴇʀ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ✎<br />
◨ ᴍᴀsᴋ sᴇʀ◧ <br />

 © HERMIT-MD
