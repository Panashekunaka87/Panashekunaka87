
<h1 align="center"> Prabath-Md Plugins </h1>
<div align="center">
<br /> 

<br> [![join](https://telegra.ph/file/798fb30f0ac7e57ce251d.jpg)](naveeddogar)
 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=SamPandey001&label=Visitors%20count&color=10d9c3&style=plastic" alt="lyfe-plugin-list" /> </p>


ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://raw.githubusercontent.com/SecktorBot/Brandimages/main/secktor.png)](https://chat.whatsapp.com/Bl2F9UTVU4CBfZU6eVnrbCl)
  <div align="center"  
<h4 align="center">Plugins</h1>

---

- Create your own plugin and join group to add that plugin in repo.

---


<h4 align="center"> Fullgpp </h1>

Set Full Group Profile Pic
```
https://gist.github.com/SuhailTechInfo/5ac882f52a000f1e51d1eb4922761c1a/raw
```
- Created By @SuhailTechInfo
---


<h4 align="center">  Editable BGM </h1>
add bgm on specific words just by repling a audio/video

```
https://gist.github.com/SamPandey001/76524c0b7b112931dad3e60559e996f0/raw/
```


---
<h4 align="center">  FaceBook Downloader </h1>

Facebook Video Downloader
```
https://gist.githubusercontent.com/SuhailTechInfo/c86b75e00c06da1743a6a5f1b18f5587/raw/ad8420a4bf3a1da515e486bbf57cda02c2f51750/fbdl-Secktor.js
```


---


<h4 align="center">  TikTok Downloader </h1>

TikTok No Watermark Downloader
```
https://gist.githubusercontent.com/SuhailTechInfo/94464b9f031789bf1023c4c03eead71c/raw/a5aa40ba3be13ae1d51d5b25e5be59ec814b252f/tiktokdl-secktor.js
```


---

<h4 align="center">  Editor Pack </h1>

Photo editor pack
```
https://gist.github.com/SamPandey001/47ce45f5519dd9d4f74b68fc675d7eb6/raw
```

---

<h4 align="center">  Pm-Permit </h1>

Pm Permit Protection
```
https://gist.github.com/SamPandey001/3157eb9b5a3b0de72da50785f84ff5fe/raw
```


---

<h4 align="center">  BGM </h1>

BGM at specific word.
```
https://gist.githubusercontent.com/SamPandey001/6d706c8725ac76cb9b8e8ccba6ef91c9/raw
```

---

<h4 align="center">  Media Pack </h1>

Media editor pack
```
https://gist.github.com/SamPandey001/a7df7517f66cf11ab5a2780536e9c08c/raw
```



---

<h4 align="center">  Mention Preview </h1>

Sends audio when someone mentios bot.
```
https://gist.githubusercontent.com/SamPandey001/eac4fa2950b5fb756e499e61aac93269/raw/61b9593692ac8ac7a516dc94d6591aa8c9808b8b
```

---

<h4 align="center">  NSFW pack </h1>

NSFW pack
```
https://gist.github.com/SamPandey001/12d97bf94224431591c92808095e89e3/raw/df844dffdcf72bc92d576b41bd0dc5f6c75a70f6/nsfw-pack.js
```

---

<h4 align="center">  Pm blocker </h1>

Pm blocker
```
https://gist.github.com/SamPandey001/42a6856ec4ccf8dda19729913b19e350/raw/e666f2038a98fadd959bb01742a2ec86a56ec8bc/pmblocker.js
```

---

<h4 align="center"> Sample Plugin </h1>

Sample of making plugins in Secktor
```
https://gist.github.com/SamPandey001/5224fb9d5d7874a58ac2388fc89720a9/raw
```

---

<h4 align="center"> shipment </h1>

```
https://gist.github.com/SamPandey001/28d55f52dd7f7d91f17bf4c1bd5b8da6/raw
```


---

<h4 align="center"> find audio </h1>

```
https://gist.githubusercontent.com/SamPandey001/15d182b7b2a4fae00dba8b04ce9e7a00/raw/
```

---

<h4 align="center"> Intro </h1>

Intro plugins
```
https://gist.github.com/SamPandey001/f96ea773e1c44cc2849f42fb7c4a968f/raw
```

---

<h4 align="center"> Audio </h1>

Audio pack
```
https://gist.github.com/SamPandey001/0b7f3d51a6b74502c236cd37b92035b2
```

---

<h4 align="center"> Text-to-Image </h1>

```
https://gist.github.com/SamPandey001/5557839a39f7558ffd24d6c7d821d34a/raw
```

---

<h4 align="center"> Weeb-UwU </h1>

```
https://gist.githubusercontent.com/SamPandey001/d17a1512da8380b8a2c5f2cf7c80b0d8/raw/25e31570b2789e5304f88f93f9ab06f0f952ca89/weeb-UwU.js
```

---

<h4 align="center"> Reaction-Pack </h1>

```
https://gist.github.com/SamPandey001/3d3c8faef08a33751186dcb56d0790b9/raw
```


